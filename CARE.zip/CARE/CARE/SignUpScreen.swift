//
//  ViewController.swift
//  CARE
//
//  Created by Mudit Dahiya on 2022-11-26.
//

import UIKit

class SignUpScreen: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

